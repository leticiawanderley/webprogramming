ECS639U Web Programming - Coursework 1
Extension of Social Network Web Application

This project consists in the adapted code from the book "Learning PHP, MySQL, JavaScript, CSS, and HTML5" using Django and Python.
With two new features:
  B) Friends	instead	of	follow
  2) Follower/Friend	recommendation
And a refactorization of the project's templates and code. 

Users in the Database:
  Login: anna         Login: bob          Login: carl         Login: daniel  
  Password: anna      Password: bob       Password: carl      Password: daniel

  Login: eve          Login: frank        Login: gail         Login: harry
  Password: eve       Password: frank     Password: gail      Password: harry
